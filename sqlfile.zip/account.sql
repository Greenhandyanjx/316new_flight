/*
 Navicat Premium Dump SQL

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80018 (8.0.18)
 Source Host           : localhost:3306
 Source Schema         : mdb

 Target Server Type    : MySQL
 Target Server Version : 80018 (8.0.18)
 File Encoding         : 65001

 Date: 24/12/2024 20:56:00
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `type` int(11) NOT NULL COMMENT '0是管理者，1是用户',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `account`(`account` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES (1, 'user1', '123456', 0);
INSERT INTO `account` VALUES (2, 'admin', '654321', 0);
INSERT INTO `account` VALUES (3, 'guest', '111111', 0);
INSERT INTO `account` VALUES (4, 'overcome', '11223', 0);
INSERT INTO `account` VALUES (5, 'cheft', '123', 0);
INSERT INTO `account` VALUES (6, 'user111', '11223', 1);
INSERT INTO `account` VALUES (7, '54', '999', 1);
INSERT INTO `account` VALUES (8, '55', '999', 1);
INSERT INTO `account` VALUES (9, '56', '999', 1);
INSERT INTO `account` VALUES (10, 'aa', 'fsrg3423', 0);
INSERT INTO `account` VALUES (11, 'aaadw', 'fsrg3423', 0);
INSERT INTO `account` VALUES (12, 'a', '1', 0);
INSERT INTO `account` VALUES (13, 'aacgvx', '23143', 0);
INSERT INTO `account` VALUES (14, 'yjx', '1', 1);

SET FOREIGN_KEY_CHECKS = 1;
