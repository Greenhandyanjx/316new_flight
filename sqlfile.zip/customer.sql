/*
 Navicat Premium Dump SQL

 Source Server         : sqlstudy
 Source Server Type    : MySQL
 Source Server Version : 80040 (8.0.40)
 Source Host           : localhost:3306
 Source Schema         : mydb1

 Target Server Type    : MySQL
 Target Server Version : 80040 (8.0.40)
 File Encoding         : 65001

 Date: 24/12/2024 19:43:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `no` int NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `type` int NOT NULL,
  `id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sex` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `account` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`no`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, '张三', 1, '110101199001011234', '男', '13800138000', 'user1');
INSERT INTO `customer` VALUES (2, '李四', 2, '110102199002022345', '女', '13800138001', 'admin');
INSERT INTO `customer` VALUES (3, '王五', 1, '110103199003033456', '男', '13800138002', 'guest');
INSERT INTO `customer` VALUES (4, '赵六', 3, '110104199004044567', '女', '13800138003', 'overcome');
INSERT INTO `customer` VALUES (5, '孙七', 1, '110105199005055678', '男', '13800138004', 'cheft');
INSERT INTO `customer` VALUES (6, '周八', 2, '110106199006066789', '女', '13800138005', 'user111');
INSERT INTO `customer` VALUES (7, '吴九', 3, '110107199007077890', '男', '13800138006', '54');
INSERT INTO `customer` VALUES (8, '郑十', 1, '110108199008088901', '女', '13800138007', '55');
INSERT INTO `customer` VALUES (9, '钱十一', 2, '110109199009099012', '男', '13800138008', '56');

SET FOREIGN_KEY_CHECKS = 1;
