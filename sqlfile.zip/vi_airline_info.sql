/*
 Navicat Premium Dump SQL

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80018 (8.0.18)
 Source Host           : localhost:3306
 Source Schema         : mdb

 Target Server Type    : MySQL
 Target Server Version : 80018 (8.0.18)
 File Encoding         : 65001

 Date: 08/12/2024 11:14:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for vi_airline_info
-- ----------------------------
DROP TABLE IF EXISTS `vi_airline_info`;
CREATE TABLE `vi_airline_info`  (
  `airlineno` int(11) NOT NULL,
  `airwayshortname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `airplanetype` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `departurecountry` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `departurecity` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `arrivecountry` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `arrivecity` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `departuredate` date NOT NULL,
  `departuretime` time NOT NULL,
  `arrivetime` time NOT NULL,
  `economyclassprice` int(11) NOT NULL,
  `economyclassnum` int(11) NOT NULL,
  `businessclassprice` int(11) NOT NULL,
  `businessclassnum` int(11) NOT NULL,
  `deluxeclassprice` int(11) NOT NULL,
  `deluxeclassnum` int(11) NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of vi_airline_info
-- ----------------------------
INSERT INTO `vi_airline_info` VALUES (1001, '南航', '波音737', '中国', '广州', '中国', '北京', '2024-12-09', '08:00:00', '10:30:00', 500, 150, 1200, 20, 2500, 10);
INSERT INTO `vi_airline_info` VALUES (1002, '东航', '空客A320', '中国', '上海', '中国', '深圳', '2024-12-10', '09:00:00', '11:45:00', 600, 160, 1300, 25, 2700, 12);
INSERT INTO `vi_airline_info` VALUES (1003, '国航', '波音747', '中国', '成都', '美国', '洛杉矶', '2024-12-11', '15:00:00', '22:00:00', 800, 200, 2000, 30, 5000, 15);

SET FOREIGN_KEY_CHECKS = 1;
