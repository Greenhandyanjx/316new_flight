/*
 Navicat Premium Dump SQL

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80018 (8.0.18)
 Source Host           : localhost:3306
 Source Schema         : mdb

 Target Server Type    : MySQL
 Target Server Version : 80018 (8.0.18)
 File Encoding         : 65001

 Date: 08/12/2024 11:14:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for vi_country_city
-- ----------------------------
DROP TABLE IF EXISTS `vi_country_city`;
CREATE TABLE `vi_country_city`  (
  `countryno` int(11) NOT NULL,
  `countryname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `provincename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `cityname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of vi_country_city
-- ----------------------------
INSERT INTO `vi_country_city` VALUES (1, '中国', '广东', '广州');
INSERT INTO `vi_country_city` VALUES (2, '中国', '北京', '北京');
INSERT INTO `vi_country_city` VALUES (3, '美国', '加州', '洛杉矶');

SET FOREIGN_KEY_CHECKS = 1;
