/*
 Navicat Premium Dump SQL

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80018 (8.0.18)
 Source Host           : localhost:3306
 Source Schema         : mdb

 Target Server Type    : MySQL
 Target Server Version : 80018 (8.0.18)
 File Encoding         : 65001

 Date: 09/12/2024 13:33:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for airline
-- ----------------------------
DROP TABLE IF EXISTS `airline`;
CREATE TABLE `airline`  (
  `airlineno` int(11) NOT NULL AUTO_INCREMENT,
  `airwayshortname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `departurecountry` int(11) NULL DEFAULT NULL,
  `departurecity` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `arrivecountry` int(11) NULL DEFAULT NULL,
  `arrivecity` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `departuredate` date NULL DEFAULT NULL,
  `departuretime` time NULL DEFAULT NULL,
  `economyclassprice` int(11) NULL DEFAULT NULL,
  `businessclassprice` int(11) NULL DEFAULT NULL,
  `deluxeclassprice` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`airlineno`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of airline
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
