/*
 Navicat Premium Dump SQL

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80018 (8.0.18)
 Source Host           : localhost:3306
 Source Schema         : mdb

 Target Server Type    : MySQL
 Target Server Version : 80018 (8.0.18)
 File Encoding         : 65001

 Date: 08/12/2024 11:14:57
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for vi_ticket_change
-- ----------------------------
DROP TABLE IF EXISTS `vi_ticket_change`;
CREATE TABLE `vi_ticket_change`  (
  `booknum` int(11) NOT NULL,
  `customername` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `airlineno` int(11) NOT NULL,
  `departurecity` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `arrivecity` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `departuredate` date NOT NULL,
  `departuretime` time NOT NULL,
  `shipno` int(11) NOT NULL,
  `shipname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of vi_ticket_change
-- ----------------------------
INSERT INTO `vi_ticket_change` VALUES (1001, '张三', 1234, '广州', '北京', '2024-12-09', '10:30:00', 567, 'CZ567');
INSERT INTO `vi_ticket_change` VALUES (1002, '李四', 1235, '上海', '深圳', '2024-12-10', '14:45:00', 568, 'MU568');
INSERT INTO `vi_ticket_change` VALUES (1003, '王五', 1236, '成都', '纽约', '2024-12-11', '22:15:00', 569, 'CA569');

SET FOREIGN_KEY_CHECKS = 1;
